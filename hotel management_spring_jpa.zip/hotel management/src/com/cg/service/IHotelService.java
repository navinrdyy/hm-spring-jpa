package com.cg.service;

public interface IHotelService {

}
