package com.cg.entity;

public class Hotel {

}
