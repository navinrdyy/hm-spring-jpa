package com.cg.controller;

public class HotelController {

}
