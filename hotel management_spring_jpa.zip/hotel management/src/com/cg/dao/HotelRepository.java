package com.cg.dao;

public class HotelRepository {

}
